package com.kishan;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("webapi")//used to map it to root url
							//it will add prefix /webapi/ to every resource
							//if we use this than we dont need to configure web.xml
public class MyApp extends Application {
	//extending Application we are telling jersey that this is jax-rs application
	//it is abstract class
	
}