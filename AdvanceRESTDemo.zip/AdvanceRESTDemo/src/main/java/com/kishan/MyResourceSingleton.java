package com.kishan;

import javax.inject.Singleton;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("test")
@Singleton //default scope of resource is request
			//change scope to singleton
public class MyResourceSingleton {
	
	private int count;

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String testMethod() {
		count = count + 1; 
		return "It works! This method was called " + count + " time(s)";
	}
	
}
