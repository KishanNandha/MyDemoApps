package com.kishan;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("{pathParam}/test")
public class MyResource {
	//always declare queryparam and path params in class level scope
	//dont use singleton if we are using class level params coz singleton instance is created before request       
	@PathParam("pathParam") private String pathParamExample;
	@QueryParam("query") private String queryParamExample;
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String testMethod() {
		//this works coz new instasnce is creasted for every request
		return "It works! Path param used " + pathParamExample + " and Query param used " + queryParamExample;
	}
	
}
