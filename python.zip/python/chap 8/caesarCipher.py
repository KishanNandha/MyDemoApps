def caesarCipherEncrypt(msg,key):
  # every possible symbol that can be encrypted
  LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  translated = ''
  msg=msg.upper()
  for symbol in msg:
    if symbol in LETTERS:
      num = LETTERS.find(symbol) # get the number of the symbol
      num = num + key
      if num >= len(LETTERS):
        num = num - len(LETTERS)
      elif num < 0:
        num = num + len(LETTERS)
      translated = translated + LETTERS[num]
    else:
      translated = translated + symbol
  return translated
  
def caesarCipherDecrypt(msg,key):
  # every possible symbol that can be encrypted
  LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  translated = ''
  msg=msg.upper()
  for symbol in msg:
    if symbol in LETTERS:
      num = LETTERS.find(symbol) # get the number of the symbol
      num = num - key
      if num >= len(LETTERS):
        num = num - len(LETTERS)
      elif num < 0:
        num = num + len(LETTERS)
      translated = translated + LETTERS[num]
    else:
      translated = translated + symbol  
  return translated
  
e=caesarCipherEncrypt("This is my secret message.",3)
d=caesarCipherDecrypt(e,3)
print(e)
print(d)
  