def reverseCipher(msg):
  return msg[::-1]
  
print(reverseCipher("Hello World"))