def insertionSort(L):
  for i in range(1, len(L)):
    key = L[i]
    j = i - 1
    while j >= 0 and key < L[j]:
      L[j+1] = L[j]
      j -= 1
    L[j+1] = key
    
  return L
list=[2,3,1,4,5,8,77,6,9]
print(insertionSort(list))