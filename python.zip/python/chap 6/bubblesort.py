def swap(x,y):
  return y,x
  
def bubbleSort(L):
  n=len(L)
  for i in range(n):
    for j in range(n-i-1):
      if(L[j]>L[j+1]):
        L[j],L[j+1]=swap(L[j],L[j+1])
  
  return L 
  
list=[2,3,1,4,5,8,77,6,9]
print(bubbleSort(list))
      