def Merge(left, right, L):
	i = j = k = 0
	while (i < len(left) and j < len(right)):
		if (left[i] < right[j]):
			L[k] = left[i]
			i += 1
		else:
			L[k] = right[j]
			j += 1
		k += 1
	while (i < len(left)):
		L[k] = left[i]
		i += 1
		k += 1
	while (j < len(right)):
		L[k] = right[j]
		j += 1
		k += 1


def MergeSort(L):
	left = []
	right = []
	n = len(L)
	if (n < 2):
		return
	mid = n // 2
	for i in range(mid):
		left.append(L[i])
	for i in range(mid, n):
		right.append(L[i])
	MergeSort(left)
	MergeSort(right)
	Merge(left, right, L)

	return L


list = [2, 3, 1, 4, 5, 8, 77, 6, 9]
print(MergeSort(list))
