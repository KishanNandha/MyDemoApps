def partition(L,start,end):
  pivot=L[end]
  pindex=start
  for i in range(start,end):
    if(L[i] <= pivot):
      L[pindex],L[i] =L[i],L[pindex]
      pindex += 1
  L[pindex],L[end] =L[end],L[pindex]
  return pindex
  
def quickSort(L,start,end):
  if start<=end:
    p=partition(L,start,end)
    quickSort(L,start,p-1)
    quickSort(L,p + 1,end)
    
  return L
  
list=[2,3,1,4,5,8,77,6,9]
print(quickSort(list,0,len(list)-1))