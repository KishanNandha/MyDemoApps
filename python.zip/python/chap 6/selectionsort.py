def selectionSort(L):
  n=len(L)
  for i in range(n):
    min = i
    for j in range(i+1, n):
      if L[min] > L[j]:
        min = j
    L[i], L[min] = L[min], L[i]
  return L
list=[2,3,1,4,5,8,77,6,9]
print(selectionSort(list))