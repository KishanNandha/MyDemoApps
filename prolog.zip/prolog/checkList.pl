list_member(X,[X|_]).
list_member(X,[_|[B]]):-list_member(A,B).
%list_member(a,[a,b,c,d,e]). true
&list_member(aa,[a,b,c,d,e]). true
%list_member([a,b],[[a,b],c,d,e]). true
%list_member([a,b],[a,b,c,d,e]). false