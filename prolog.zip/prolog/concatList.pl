concat([],L,L).
concat([X1|L1],L2,[X1|L3]):-concat(L1,L2,L3).

% concat([a,b,c],[e,f,g,h],L).  L = [a,b,c,e,f,g,h]
% know second list concat([a,b,c],L,[a,b,c,e,f,g,h]).  L = [e,f,g,h]
% concat([],[e,f,g,h],L).  L = [e,f,g,h]

