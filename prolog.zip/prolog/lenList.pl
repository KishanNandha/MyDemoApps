len_list([],0).
len_list([_|Tail],N):-len_list(Tail,N1),N is N1+1.

% len_list([a,b,c,d,e],L).    L = 5
% len_list([],L). L = 0