animal(dog).
animal(elephant).
animal(tiger).
animal(cobra).
animal(python).
animal(cat).
snake(cobra).
snake(python).

likes(mary,X) :- snake(X), !, fail.
likes(mary,X) :- animal(X).

/*
yes
| ?- likes(mary,tiger).

yes
| ?- likes(mary,tiger).

yes
| ?- likes(mary,python).

no
| ?- likes(mary,cobra).

no
| ?- likes(mary,cat).

no
| ?- likes(mary,dog).

yes
| ?- likes(mary,cat).

no
| ?- likes(mary,cat).

no
*/