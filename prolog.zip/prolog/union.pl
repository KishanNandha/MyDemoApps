
list_member(X,[X|_]).
list_member(X,[_|Tail]):-list_member(X,Tail).

unionL([X|Y],Z,W):- list_member(X,Z), unionL(Y,Z,W).
unionL([X|Y],Z,[X|W]):- \+ list_member(X,Y), unionL(Y,Z,W).
unionL([],Z,Z).

%unionL([1,2,3,4,5],[1,a,b,c,3,4],X). X = [2,5,1,a,b,c,3,4] ? 