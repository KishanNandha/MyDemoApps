
/* 
f(X,0) :- X<3.
f(X,2) :- 3 =< X,X <6.
f(X,4) :- 6=< X.

yes
| ?- trace.
The debugger will first creep -- showing everything (trace)

yes
{trace}
| ?- f(1,Y),2<Y.
      1    1  Call: f(1,_23) ? 
      2    2  Call: 1<3 ? 
      2    2  Exit: 1<3 ? 
      1    1  Exit: f(1,0) ? 
      3    1  Call: 2<0 ? 
      3    1  Fail: 2<0 ? 
      1    1  Redo: f(1,0) ? 
      2    2  Call: 3=<1 ? 
      2    2  Fail: 3=<1 ? 
      2    2  Call: 6=<1 ? 
      2    2  Fail: 6=<1 ? 
      1    1  Fail: f(1,_23) ? 

(16 ms) no
{trace}
| ?- 
*/


f(X,0) :- X<3,!.
f(X,2) :- 3 =< X,X <6,!.
f(X,4) :- 6=< X.

/* 
yes
{trace}
| ?- f(1,Y),2<Y.
      1    1  Call: f(1,_23) ? 
      2    2  Call: 1<3 ? 
      2    2  Exit: 1<3 ? 
      1    1  Exit: f(1,0) ? 
      3    1  Call: 2<0 ? 
      3    1  Fail: 2<0 ? 

no
{trace}
| ?- 
*/