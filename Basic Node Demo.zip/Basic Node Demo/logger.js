function info(data) {
    console.log("This is Logger "+data);
}
module.exports.log = info;