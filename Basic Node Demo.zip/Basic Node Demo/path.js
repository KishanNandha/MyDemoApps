const pathModule = require('path');
let pathObj = pathModule.parse(__filename);
console.log(pathObj);