const os = require('os');
console.log(os.freemem());
console.log(os.totalmem());