package com.kishan.resources;


import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

@Path("/injectdemo")
@Consumes(MediaType.TEXT_PLAIN)
@Produces(MediaType.TEXT_PLAIN)
public class InjectDemoResource {
	
	
	//matrix param:type of query param
	//query param http://localhost:8080/messenger/webapi/injectdemo/annotations?param=value
	//matrix param http://localhost:8080/messenger/webapi/injectdemo/annotations;param=value
	//HeaderParam:custom header params
	//Cookie param:custom cookie params
	//set HeaderParam and Cookie param in postman
	@GET
	@Path("annotations")
	public String getParamsUsingAnnotations(@MatrixParam("param") String matrixParam,
											@HeaderParam("authSessionID") String header,
											@CookieParam("name") String cookie) {
		return "Matrix param: " + matrixParam + " Header param: " + header + " Cookie param: " + cookie;
	}
	//used when we want all params //like all cookie params or all header params
	// also used when we dont know name of param
				
	@GET
	@Path("context") //@context is special type of annotation used with some class like UriInfo
	public String getParamsUsingContext(@Context UriInfo uriInfo, @Context HttpHeaders headers) {
		//UriInfo gives uri releted informations
		//HttpHeaders gives HTTP header informations
		String path = uriInfo.getAbsolutePath().toString();
		String cookies = headers.getCookies().toString();
		return "Path : " + path + " Cookies: " + cookies;
	}
	
	
	

}
