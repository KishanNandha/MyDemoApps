package com.kishan.resources;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import com.kishan.models.Message;
import com.kishan.resources.beans.MessageFilterBean;
import com.kishan.service.MessageService;

@Path("/messages") // path for resource
@Consumes(MediaType.APPLICATION_JSON) // tells jersey what is input type
@Produces(value = {MediaType.APPLICATION_JSON,MediaType.TEXT_XML}) // tells jersey what is return type
//for getting value 
public class MessageResource {

	MessageService messageService = new MessageService();

	/*
	 * @GET //get method    //http://localhost:8080/messenger/webapi/messages?year=2018
	 * 						// http://localhost:8080/messenger/webapi/messages //
	 * 						//http://localhost:8080/messenger/webapi/messages?start=0&size=2 public
	 * List<Message> getMessages(@QueryParam("year") int year,
	 * 								@QueryParam("start") int start,
	 * 								@QueryParam("size") int size) 
	 *{
	 *	 if(year > 0) return
	 *	 messageService.getAllMessagesForYear(year); if(start >= 0 && size >= 0)
	 *	 return messageService.getAllMessagesPaginated(start, size); return
	 * 	messageService.getAllMessages(); 
	 * }
	 */

	//instead of using separate params we can use bean of params
	
	@GET // get method
	// http://localhost:8080/messenger/webapi/messages?year=2018
	// http://localhost:8080/messenger/webapi/messages
	// http://localhost:8080/messenger/webapi/messages?start=0&size=2
	public List<Message> getMessages(@BeanParam MessageFilterBean filterBean) {
		
		if (filterBean.getYear() > 0) {
			return messageService.getAllMessagesForYear(filterBean.getYear());
		}
		if (filterBean.getStart() >= 0 && filterBean.getSize() > 0) {
			return messageService.getAllMessagesPaginated(filterBean.getStart(), filterBean.getSize());
		}
		return messageService.getAllMessages();
	}
	
	
	//@POST // post method
	//public Message addMessage(Message message) {
		//return messageService.addMessage(message);
	//}
	
	//returning status code 201 insteade of 200 and returining link
	@POST // post method
	public Response addMessage(Message message) throws URISyntaxException {
		Message msg= messageService.addMessage(message);
		// return Response.status(Status.CREATED).entity(msg).build(); // only status
		//status with location NOTE: location will come in header part not in json 
		return Response.created(new URI("/messenger/webapi/messages/"+msg.getId())).entity(msg).build();
	}

	
	@PUT // put method
	@Path("/{messageId}")
	public Message updateMessage(@PathParam("messageId") long id, Message message) {
		message.setId(id);// pick up id from url
		return messageService.updateMessage(message);
	}

	@DELETE // delete method
	@Path("/{messageId}")
	public void deleteMessage(@PathParam("messageId") long id) {
		messageService.removeMessage(id);
	}

	//with out links
	/*@GET
	@Path("/{messageId}")
	public Message getMessage(@PathParam("messageId") long messageId) {
		return messageService.getMessage(messageId);
	}*/
	
	//with links
	@GET
	@Path("/{messageId}")
	public Message getMessage(@PathParam("messageId") long id, @Context UriInfo uriInfo) {
		Message message = messageService.getMessage(id);
		message.addLink(getUriForSelf(uriInfo, message), "self");
		message.addLink(getUriForProfile(uriInfo, message), "profile");
		message.addLink(getUriForComments(uriInfo, message), "comments");
		
		return message;
		
	}

	
	//this method does not contain method type so it works for all methods
	//this method returns comment resource instance
	@Path("/{messageId}/comments")
	public CommentResource getCommentResource() {
		return new CommentResource();
	}
	
	
	private String getUriForComments(UriInfo uriInfo, Message message) {
		URI uri = uriInfo.getBaseUriBuilder()
				.path(MessageResource.class)// it will add /messages
	       		.path(MessageResource.class, "getCommentResource")//it will add /{messageId}/comments"
	       		.path(CommentResource.class)//it will add /comments
	       		.resolveTemplate("messageId", message.getId())// it will replace {messageId} to message id
	            .build();
	    return uri.toString();
	}

	private String getUriForProfile(UriInfo uriInfo, Message message) {
		URI uri = uriInfo.getBaseUriBuilder()
       		 .path(ProfileResource.class)//it will add /profiles
       		 .path(message.getAuthor())//it will add/ author name 
             .build();
        return uri.toString();
	}

	private String getUriForSelf(UriInfo uriInfo, Message message) {
		String uri = uriInfo.getBaseUriBuilder()
		 .path(MessageResource.class) //it will add data(url mapping) with / eg: for MessageResource it will add /messages
		 .path(Long.toString(message.getId()))// it will just add /string
		 .build()
		 .toString();
		return uri;
	}
	
}
