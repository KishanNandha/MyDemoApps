import { LoginServiceService } from './dependency-injection/login-service.service';
import { LogServiceService } from './dependency-injection/log-service.service';
import { GithubFollowersService } from './services/github-followers.service';
import { PostService } from './webservice/post.service';
import { SummaryPipe } from './pipes/summary.pipe';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule} from '@angular/core';
import { RouterModule} from '@angular/router';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { BindingsComponent } from './bindings/bindings.component';
import { PipesComponent } from './pipes/pipes.component';
import { DirectivesComponent } from './directives/directives.component';
import { WebserviceComponent } from './webservice/webservice.component';
import { MyErrorHandler } from './webservice/myErrorHandler';
import { ErrorHandler } from "@angular/core";
import { RoutingComponent } from './routing/routing.component';
import { NavbarComponent } from './routing/navbar/navbar.component';
import { GithubFollowersComponent } from './routing/github-followers/github-followers.component';
import { GithubProfileComponent } from './routing/github-profile/github-profile.component';
import { NotFoundComponent } from './routing/not-found/not-found.component';
import { HomeComponent } from './routing/home/home.component';
import { DependencyInjectionComponent } from './dependency-injection/dependency-injection.component';

@NgModule({
  declarations: [
    AppComponent,
    BindingsComponent,
    PipesComponent,
    SummaryPipe,
    DirectivesComponent,
    WebserviceComponent,
    RoutingComponent,
    NavbarComponent,
    GithubFollowersComponent,
    GithubProfileComponent,
    NotFoundComponent,
    HomeComponent,
    DependencyInjectionComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
     RouterModule.forRoot([
      { path: '', component: HomeComponent},
      { path: 'followers', component: GithubFollowersComponent},
      { path: 'followers/:id/:username', component: GithubProfileComponent},
      { path: 'posts', component:  WebserviceComponent},
      { path: '**', component:  NotFoundComponent}
    ]) 
  ],
  providers: [
    PostService,
    GithubFollowersService,
    { provide: ErrorHandler, useClass: MyErrorHandler },
    LoginServiceService,
    LogServiceService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
